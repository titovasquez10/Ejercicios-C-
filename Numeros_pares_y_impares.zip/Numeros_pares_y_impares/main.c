#include <stdio.h>

int main(int argc, char **argv)
{
    float num[20];
    int num_impares, num_pares;
    
    num_impares = 0;
    num_pares = 0;
    
    int n;
    for(n<0; n<20; n++)
    {    
        printf("Digite 20 numeros");
        scanf("%f",&num[20]);
    
        if(num[n]% 2 = 0)
        {
            num_pares++;
        }
        
        else
        {
            if(num[n]% 2 != 0)
            {
            num_impares++;
            }
        }
    }
    
    printf("\nLos numeros pares son", num_pares);
    printf("\nLos numeros impares son", num_impares);
    
    
	return 0;
}
