#include <stdio.h>

	#define CORTES 3
	#define ESTUDIANTES 2
	
	float NotasCurso[ CORTES ] [ ESTUDIANTES ];
	
	void LeerNotas();
	float PromedioCorte(int corte);
	float PromedioEstudiante(int estudiante);
	
int main()
{
	float promCorte;
	int cualcorte;
	float promEstudiante;
	int estudiante;
	LeerNotas();
	
	printf("¿De que corte quiere calcular el promedio? (1,2 3): ");
	scanf("%d",&cualcorte);
	promCorte = PromedioCorte(cualcorte-1);
	printf("El promedio del corte %d es: %f", cualcorte, promCorte);
	
	printf("\n¿Desea saber el promedio de un estudiante? (1,2): ");
	scanf("%d",&estudiante);
	promEstudiante = PromedioEstudiante(estudiante-1);
	printf("El promedio del estudiante %d es: %f", estudiante, promEstudiante);
	
	return 0;
}

void LeerNotas()
{
	int i, j;
	for(i = 0; i < CORTES; i++)
	{
		for(j = 0; j < ESTUDIANTES; j++)
		{
			printf("Ingrese la nota del corte %d, para el estudiante %d: ", (i+1),(j+1));
			scanf("%f",&NotasCurso[i][j]);
		}
	}
}

float PromedioCorte( int corte)
{
	float promedio, suma = 0;
	
	int j;
	for(j = 0; j < ESTUDIANTES; j++)
	{
		suma = suma + NotasCurso[corte][j];
	}
	promedio = suma / ESTUDIANTES;	

	return promedio;
}

float PromedioEstudiante(int estudiante)
{
	float promEstudiante, suma = 0;
	
	int i;
	for(i = 0; i < CORTES; i++)
	{
		suma = suma + NotasCurso[i][estudiante];
	}
	promEstudiante = suma / CORTES;
	
	return promEstudiante;
}
