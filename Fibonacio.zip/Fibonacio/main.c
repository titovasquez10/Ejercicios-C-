#include <stdio.h>

int main(int argc, char **argv)
{
	
	long fibonacci[50];
	
	fibonacci[0] = 0;
	fibonacci[1] = 1;
	
	printf("Serie de fibonacci:\n");
	
	int n;
	for(n=2; n < 50; n++)
	{
		fibonacci[n] = fibonacci[n-1] + fibonacci[n-2];
		printf("Termino %u : %u\n",n,fibonacci[n]);
	}	
	
	
	return 0;
}
