#include <stdio.h>

#define FILAS 4
#define COLUMNAS 4


int matrix[ FILAS ]  [ COLUMNAS ]

int main()
{
	readDatos()
	
	return 0;
}

void readDatos()
{
	for(int i = 0; i < FILAS; i++)
	{
		for(int j = 0; i < COLUMNAS; i++)
		{
			printf("Digite el numero en la posicion [ %d ] [ %d ]: ", i,j);
			scanf("%d",&matrix[i][j]);
		}
	}
} 


int RestarFila(int fila)
{
	int resta = 0;
	for(i=0; i<COLUMNAS; i++)
	{
		resta = resta - matrix [ fila ][ i ];
	}
	
	return resta;
}

int RestarColumna(int columna)
{
	int resta = 0;
	for(i=0; i< FILAS; i++)
	{
		resta = resta - matrix [ j ][ columa ];
	}
	return resta;
}


