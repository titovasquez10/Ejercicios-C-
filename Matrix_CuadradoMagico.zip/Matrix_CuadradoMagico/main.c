#include <stdio.h>

#define FILAS 3
#define COLUMNAS 3

int cuadrado[ FILAS ] [ COLUMNAS ];

int main()
{	
	LeerDatos();
	
	if(SumarFila(0) == SumarFila(1) && 
		SumarFila(0) == SumarFila(2) && 
		SumarFila(0) == 15 && 
		SumarColumna(0) == SumarColumna(1) &&	
		SumarColumna(0) == SumarColumna(2)&&
		SumarColumna(0) == 15 &&
		SumaDiagonal(1) == SumaDiagonal(2) && SumaDiagonal(1) == 15 )
		{
			printf("\nEs un cuadrado magico");
		}	
		else
		{
			printf("\nNo es un cuadrado mágico");
		}
	
	return 0;
}

void LeerDatos()
{
	for(int i = 0; i < FILAS; i++)
	{
		for(int j = 0; j < COLUMNAS; j++)
		{
			printf("Digite el numero en la casilla [ %d ] [ %d ]: ",i,j);
			scanf("%d",&cuadrado[i][j]);
		}
	}
}


int SumarFila(int fila)
{
	int suma = 0;
	for(int i = 0; i < COLUMNAS; i++)
	{
		suma = suma + cuadrado [ fila ] [ i ];
	}
	return suma;
}

int SumarColumna(int columna)
{
	int suma = 0;
	for (int j=0; j < FILAS; j++)
	{
		suma = suma + cuadrado [ j ] [ columna ];
	}
	return suma;
}

int SumaDiagonal(int cualDiagonal)
{
	int suma = 0;
	if(cualDiagonal == 1)
	{
		suma = cuadrado[0][0] + cuadrado [1][1] + cuadrado [2][2];
	}
	else
		if(cualDiagonal == 2)
		{
			suma = cuadrado[2][0] + cuadrado [1][1] + cuadrado [0][2];
		}
		return suma;
}

