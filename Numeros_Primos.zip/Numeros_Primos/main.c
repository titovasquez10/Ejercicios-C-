#include <stdio.h>

int main(int argc, char **argv)
{

	int num;
	
	printf("Digite un numero");
	scanf("%d",&num);
	
	if(num % num == 0)
	{
		printf("\n el numero no es primo %d",num);
	}
	
	
	else 
	{
		printf("\n el numero es primo %d",num);
	}

	return 0;
}
