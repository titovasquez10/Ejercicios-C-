#include <stdio.h>

int main(int argc, char **argv)
{
	
	int a, total, tabla1[10];
	
	
	printf("\nEscriba el numero de la tabla de multiplicar que desea saber: ");
	scanf("%d",&a);
	
	int n;
	for(n=1; n < 10; n++) {
	
	if(a == 5 )
	{
	total = 5 * n+5;
	}
	printf("\nla tabla del 5 es: %d", total);
	}
	
	
	
	return 0;
}
