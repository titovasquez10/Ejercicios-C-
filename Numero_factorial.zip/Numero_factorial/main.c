#include <stdio.h>

int main(int argc, char **argv)
{
	{
	int num;
	int acomulador = 1;
	
	printf("Digite un numero");
	scanf("%d",&num);
		
	if(num>0)
	{
		for(int n=1; n<=num; n++) {
			acomulador *= n;
			printf ("El factorial de %d",acomulador);
			}
	}

	return 0;
}

}
