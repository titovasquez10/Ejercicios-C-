#include <stdio.h>

int main(int argc, char **argv)
{
	
	float suma, promedio, numeros[10];
	int cuantosMayores, cuantosMenores;
	
	cuantosMayores = 0;
	cuantosMenores = 0;
	suma = 0;
	
	int n;
	for (n=0; n < 10; n++)
	{
		//El %f es para escaniar un real"float"
		printf("\nEscriba numero en la posicion %d: ",n);
		scanf("%f",&numeros[n]);
		
		//Sumar numero:
		
		//primera forma de incrementar el valor de una variable
		//suma = suma + numeros[n];
		
		//Segunda forma
		suma += numeros[n];
	}
	
	promedio = suma /10;
	printf("El promedio es %f", promedio);
	
	for (n=0; n < 10; n++)
	{	
		//primera forma
		//cuantosMayores = cuantosMayores +1
		
		//segunda forma
		//cuantosMayores +=1;
		
		//3a forma
		//cuantosMayores++;
		
		if(numeros[n] > promedio)
		{
			cuantosMayores = cuantosMayores + 1;
		}
		
		else
		{
			if(numeros[n] < promedio)
			{
				cuantosMenores = cuantosMenores +1;
			}	
		}
	}
	
	printf("\nHay %d numeros mayores al promedio", cuantosMayores);
	
	printf("\nHay %d numeros menores al promedio", cuantosMenores);
	
	return 0;
}
