#include <stdio.h>

#define MAX_INTENTOS 3
#define NUM_OPCIONES 4

char*Documento;
char*Contrasena;

char*OpcionesMenu[NUM_OPCIONES] = {"Registrar Evento",
								   "Consultar Evento poe facultad",
								   "Consultar por docente",
								   "Salir"}; 
 
int main()
{	
	int seleccion;
	printf("---Sistema de Registro de Eventos de Extension---");
	RegistrarUsuario();
	system("cls");
	if(AutenticarUsuario() ==1)
	{
		system("cls");
		printf("Credenciales correctas, bienvenido.");
		MostrarMenu();
	 do{
		seleccion = MostrarMenu();
		switch(seleccion)
		{
			system("pause");
		case 1:RegistrarEvento();
				break;
		case 2:ConsultarEventoPorFaculta();
				break;
		case 3:ConsultarEventoPorDocente();
				break;
		}
	 }while(seleccion!=4);
	}

	else
	{
		system("cls");
		printf("Ud no esta autorizado");
		return 0;
	}
	return 0;
}

void RegistrarUsuario()
{
	printf("\n>>>Registro");
	printf("\nIngrese el numero de su documento:\n");
	scanf("%s",&Documento);
	printf("\nIngrese su contrasena:\n");
	scanf("%s",&Contrasena);	
}


int AutenticarUsuario()
{
	char*unDocumento;
	char*unaContrasena; 
	printf("\n>>>Registro");
	
	for(int i = 0; i < MAX_INTENTOS; i++)
{
	printf("\nIntento de ingreso: %d",i+1);
	printf("\nIngrese el numero de su documento:\n");
	scanf("%s",&unDocumento);
	printf("\nIngrese su contrasena:\n");
	scanf("%s",&unaContrasena);	
	
	if(unDocumento == Documento && unaContrasena == Contrasena)
	{
	return 1;	
	}
	
}
	return 0;
}

int MostrarMenu()
{
	int seleccion;
	for(int i = 0; i<NUM_OPCIONES; i++)
	{
		printf("\n\t\t%d. %s\n",i+1,OpcionesMenu[i]);
	}
	printf("\nSelecione una opcion: ");
	scanf("%d",&seleccion);
	return seleccion;
}


void RegistrarEvento()
{
	
}

void ConsultarEventoPorFaculta()
{
	
}

void ConsultarEventoPorDocente()
{
	
}