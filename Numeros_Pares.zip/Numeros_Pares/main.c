#include <stdio.h>

int main(int argc, char **argv)
{
	
	int num;
	
	printf("Digite un numero: ");
	scanf ("%d",&num);
	
	if(num %2 == 0)
	{
		printf("\nEl numero es par");
	}
	
	if(num %2 == 1)
	{
		printf("\nEl es numero impar");
	}
	
	return 0;
}
