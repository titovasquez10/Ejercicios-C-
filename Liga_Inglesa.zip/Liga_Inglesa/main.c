#include <stdio.h>

char *Equipos[4] = {"Chelsea",
					"Arsenal",
					"Tottenham Hotspur",
					"Whest Ham utd"};
					
char *TituloColumna[6] = {"\nPartidos Jugados: ",
						  "\nPartidos Ganados: ",
						  "\nPartidos Empatados: ",
					      "\nPartidos Perdidos: ",
					      "\nGoles a Favor: ",
					      "\nGoles en Contra: "};					

#define FILAS 4
#define COLUMNAS 8

int TablaResultados [FILAS] [COLUMNAS];
char *NombreEquipoLider();
char *NombreEquipoGoleador();

int main()
{
	LeerDatos();
	printf("\nEl equipo lider es el %s", NombreEquipoLider() );
	printf("\nEl equipo goleador es %s", NombreEquipoGoleador()); 
	return 0;
}

void LeerDatos()
{
	for(int i= 0; i < FILAS; i++)
	{
		printf("\nDatos del %s",Equipos[i]);
		
		for(int j=0; j < 6; j++)
		{
		printf("%s", TituloColumna[j]);
		scanf("%d",&TablaResultados[i][j]);
		/*	
		printf("\nIngrese numero de partidos Jugados: ");
		scanf("%d",&TablaResultados[i][0]);
		
		printf("\nIngrese numero de partidos Ganados: ");
		scanf("%d",&TablaResultados[i][1]);
		
		printf("\nIngrese numero de partidos Empatados: ");
		scanf("%d",&TablaResultados[i][2]);
		
		printf("\nIngrese numero de partidos Perdidos: ");
		scanf("%d",&TablaResultados[i][3]);
		
		printf("\nIngrese numero de goles a Favor: ");
		scanf("%d",&TablaResultados[i][4]);
		
		printf("\nIngrese numero de goles en Contra: ");
		scanf("%d",&TablaResultados[i][5]);
		*/
		}
		
		TablaResultados[i][6] = 3 * TablaResultados[i][1] + 1 * TablaResultados[i][2];
		TablaResultados[i][7] = TablaResultados[i][4] - TablaResultados[i][5];
		
		

	}	
}

char *NombreEquipoLider()
{
	int mayorPuntaje = 0, filaMayor;
	char *EquipoLider;
	for(int i = 0; i < FILAS; i++)
	{
		if( TablaResultados[i][6] > mayorPuntaje)
		{
			mayorPuntaje = TablaResultados[i][6];
			filaMayor = i;
		}
	}
	
	EquipoLider = Equipos[filaMayor];
	return EquipoLider;
}


char *NombreEquipoGoleador()
{
	int mayorGoles = 0, fmayor;
	char*EquipoGoleador;
	for(int i = 0; i < FILAS; i++)
	{
		if(TablaResultados[i][7] > mayorGoles)
		{
			mayorGoles = TablaResultados[i][7];
			fmayor = i;
		}
		EquipoGoleador = Equipos[fmayor];
		return EquipoGoleador;
	}
	
	
}